
1. Dentro de la carpeta "tests" ejecutamos el siguiente comando para correr mocks y test

    > gulp mockLocal
    > gulp bdd
